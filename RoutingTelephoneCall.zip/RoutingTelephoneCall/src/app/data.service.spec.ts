import { TestBed } from '@angular/core/testing';
import {  CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DataService } from './data.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';

describe('DataService', () => {

 
  let httpservice : HttpClient;
  let dataService : DataService;
  beforeEach(() =>{ TestBed.configureTestingModule({
    imports: [      HttpClientModule ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA,  NO_ERRORS_SCHEMA]
  })

  
});

  

  it('should be created', () => {
    const service: DataService = TestBed.get(DataService);
    expect(service).toBeTruthy();
  });


  
  it('should be created', () => {
    const service: DataService = TestBed.get(DataService);
    expect(service).toBeTruthy();
  });

  it('to test http get method data ', () => {
    const service: DataService = TestBed.get(DataService);
    let result : any = [] ;
    service.loadOperatorData().subscribe((data) => {result = data});
    expect(result).toBeDefined();
  });



});
