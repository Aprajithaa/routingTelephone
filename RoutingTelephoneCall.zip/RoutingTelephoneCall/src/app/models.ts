export interface PhoneOperators
{
    prefix : string;
    cost : number;
}