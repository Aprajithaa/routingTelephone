import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoutingCallComponent } from './routing-call/routing-call.component';
import { OperatorComponent } from './operator/operator.component';
import { LogoutComponent } from './logout/logout.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

const routes: Routes = [
  {path : '',redirectTo:'routing', pathMatch:'full'  },
  {path : 'routing', component : RoutingCallComponent},
  {path : 'operator', component : OperatorComponent},
  {path : 'logout', component : LogoutComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
  
})
export class AppRoutingModule { }
