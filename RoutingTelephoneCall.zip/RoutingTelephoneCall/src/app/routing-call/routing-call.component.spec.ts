import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {  CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { RoutingCallComponent } from './routing-call.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
describe('RoutingCallComponent', () => {
  let component: RoutingCallComponent;
  let fixture: ComponentFixture<RoutingCallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule,HttpClientModule ],
      declarations: [ RoutingCallComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA,  NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoutingCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();

  });

  it('when passing -  null data  - to find best operator', () => {
    
    const result = component._findBestOperator(null)
    //to check equal use tobe 
    expect(result).toBeNull();
     
  });

  
  it('when passing - empty string data - to find best operator', () => {
    
    const result = component._findBestOperator(null)
    //to check equal use tobe 
    expect(result).toBeNull();
     
  });

  
});
