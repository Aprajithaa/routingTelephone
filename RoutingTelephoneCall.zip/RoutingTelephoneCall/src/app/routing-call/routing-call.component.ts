import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from '../data.service';
 

@Component({
  selector: 'app-routing-call',
  templateUrl: './routing-call.component.html',
  styleUrls: ['./routing-call.component.css']
})
export class RoutingCallComponent implements OnInit, OnDestroy {

  constructor(public httpService : DataService) { }

  ngOnDestroy()
  {
    // to unsubscribe rxjs operators..
  }

  ngOnInit() {
    this._searchOperator('');
  }
  operators : any = null; 
  phoneNumber : string;
  filterOperator : any = [];
  bestOperator : any =null;

  /* Fucntion to load the operator data initially from http service
  * phoneNumber Variable - to hold the phone number entered
    operators - to handle main collection from json    
   */
  _searchOperator(phoneData : any)
  {
    debugger;
    this.phoneNumber = phoneData.phoneNo;
    if(this.operators == null)
    {
    this.httpService.loadOperatorData().subscribe(
      (result) =>{
       
          this.operators = result;
          this.httpService.appOperator = this.operators;
          

      },
      (error)=>
      {
       
        console.log('Error in returning the Result !!');
      },
      () =>
      {
        
        console.log('Data Completed');
      } );

  }

  if( this.phoneNumber != undefined && this.phoneNumber != "" && this.operators != null)
    {
            this._findBestOperator(this.operators);
    }
}

/* Fucntion to find the best operator by matching the prefix and low cost.
  * filterOperator Variable - to hold the best price in each operator
  * bestOperator variable - to hold the final object.
   */
  _findBestOperator(mainOperators)
  {

    this.bestOperator = null;
    this.filterOperator = [];
    
    if(mainOperators !=null && mainOperators != "")
    {
    
          for(let operator in mainOperators)
          {
          // var data : any = [];
            
          // data = obj;
            let tempResult =  mainOperators[operator].filter((item) =>
            { 
              if(this.phoneNumber.startsWith(item.prefix))
              return item;
            });
            var maxPrefix = tempResult.length > 0 ? tempResult[0] : null;
            tempResult.forEach((value) =>
            {
              if(  maxPrefix.prefix.length < value.prefix.length)
              {
                    maxPrefix =value;
              }
            });

            if(maxPrefix != null)
            {
              const tempObj  : any = {};
              tempObj.operator =  operator;
              tempObj.prefix = maxPrefix.prefix;
              tempObj.cost = maxPrefix.cost;
              this.filterOperator.push(tempObj);
            }
          }
        
        
          this.bestOperator = this.filterOperator[0]
        for(var i = 0;i< this.filterOperator.length ; i++)
        {
          if(i+1 < this.filterOperator.length)
          {
            let a  = Number(this.filterOperator[i].cost) ;
            let b= Number(this.filterOperator[i+1].cost);
            if(a < b)
            {
              this.bestOperator = this.filterOperator[i]
            }
            else{
              this.bestOperator = this.filterOperator[i+1]
            }
          }
        }
       
  }
  else
  {

    return null;
  }
}

}
